// swagger.js
import swaggerJsdoc from "swagger-jsdoc";

const swaggerDefinition = {
  openapi: "3.0.0",
  info: {
    title: "JP Tactical Bitácora API",
    version: "1.0.0",
    description:
      "Documentación profesional de la API de posiciones y rentabilidad",
    contact: {
      name: "Mauricio Chara - Maobits",
      email: "code@maobits.com",
      url: "https://www.instagram.com/maobits.io",
    },
  },
  servers: [
    {
      url: "https://ttrading.shop:4000/api",
      description: "Servidor en producción",
    },
    {
      url: "http://localhost:4000/api",
      description: "Servidor local",
    },
  ],
};

const options = {
  swaggerDefinition,
  apis: ["./routes/*.js", "./modules/**/*.js"], // Asegúrate de que las rutas están bien
};

export const swaggerSpec = swaggerJsdoc(options);
